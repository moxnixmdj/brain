"""Static registry for zipped ARC symbolic ensemble vendor.

Generated from pinned donor commit; filesystem discovery replaced only so the
plugin set remains importable through Python zipimport.
"""
import importlib
import detectors as base

MODULES = ['color_neighbor', 'composition', 'counting', 'denoise', 'downsample_presence', 'lines_flood', 'mirror_concat', 'obj_recolor', 'obj_select_crop', 'panel_overlay', 'panel_select', 'periodicity', 'r2_b0', 'r2_b1', 'r2_b2', 'r2_b3', 'r2_b4', 'r2_b5', 'r3_connect_dots', 'r3_containment', 'r3_frames_rect', 'r3_grid_split_color', 'r3_obj_complete', 'r3_obj_move', 'r3_pattern_growth', 'r4_b0', 'r4_b1', 'r4_b2', 'r4_b3', 'r4_b4', 'r4_b5', 'r5_b0', 'r5_b1', 'r5_b2', 'r5_b3', 'r5_b4', 'r5_b5', 'r6_b2', 'search', 'shape_dict', 'sym_repair']

def load_all(verbose=False):
    all_dets = list(base.DETECTORS)
    for name in MODULES:
        mod = "gen." + name
        try:
            m = importlib.import_module(mod)
            dets = list(getattr(m, "DETECTORS", []))
            all_dets += dets
            if verbose:
                print(f"  + {mod}: {len(dets)} detectors")
        except Exception as e:
            if verbose:
                print(f"  ! skip {mod}: {e}")
    return all_dets

ALL = load_all()
