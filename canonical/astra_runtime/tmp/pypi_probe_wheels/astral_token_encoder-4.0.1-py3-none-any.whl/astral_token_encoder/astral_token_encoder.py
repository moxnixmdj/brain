# ATE - Astral Toker Encoder
import datetime
import secrets
import string
from typing import Optional
import logging
import hashlib
sVersions = range(1, 5)
logging.basicConfig(level=logging.ERROR, format="%(asctime)s - %(levelname)s - %(message)s")
class NoVersionError(Exception):
    def __init__(self, message):
        super().__init__(message)
class InvalidIDError(Exception):
    def __init__(self, message):
        super().__init__(message)
characters = string.ascii_letters + string.digits + string.punctuation
V4chars = string.ascii_letters + string.digits + "".join(["!", "@", "#", "$", "%", "^", "&", "*", "(", ")", "-", "=", "+", "[", "]", "<", ">", ".", ",", "?"])
class Ast:
    @staticmethod
    def IsDataTokenValid(token):
        """Checks if token if subformat is Data. If not, returns False, if it's Data returns True"""
        if "%" not in token or token.startswith("TFT_") or token.startswith("DFT_") or token.startswith("APIFTURLS_") or token.startswith("CFT_") or token.startswith("UFT_"):
            return False
        return True
    @staticmethod
    def DecodeDataToken(token: str, format: str):
        """Decodes your tokens, accepts only subformat Data, as The name says"""
        import json
        import sqlite3
        parts = token.split('%', maxsplit=4)
        d1 = parts[0] if len(parts) > 0 else None
        d2 = parts[1] if len(parts) > 1 else None
        d3 = parts[2] if len(parts) > 2 else None
        d4 = parts[3] if len(parts) > 3 else None
        d5 = parts[4] if len(parts) > 4 else None
        data_dict = {
            "data1": d1,
            "data2": d2,
            "data3": d3,
            "data4": d4,
            "data5": d5
        }
        fmt = format.lower().strip()
        if fmt == "json":
            return json.dumps(data_dict, ensure_ascii=False, indent=4)
            
        elif fmt == "dict" or fmt == "python":
            return data_dict
            
        elif fmt == "sqlite" or fmt == "db":
            conn = sqlite3.connect("tokens.db")
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS decoded_tokens (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    token TEXT,
                    data1 TEXT,
                    data2 TEXT,
                    data3 TEXT,
                    data4 TEXT,
                    data5 TEXT
                )
            """)
            cursor.execute("""
                INSERT INTO decoded_tokens (token, data1, data2, data3, data4, data5)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (token, d1, d2, d3, d4, d5))
            
            conn.commit()
            conn.close()
            return "Successfully saved to SQLite (tokens.db)"
        else:
            raise ValueError(f"Unknown format: {format}. Use 'json', 'dict', or 'sqlite'.")
    class Token:
        @staticmethod
        def t(version: Optional[int]=3) -> str:
            """Normal universal token"""
            if version not in sVersions:
                error_msg = f"Version {version} is not yet here. Please use lower versions."
                logging.error(error_msg)
                raise NoVersionError(error_msg)
            if version == 1:
                part_1 = "".join([secrets.choice(string.digits) for _ in range(10)])
                part_1 = f"UFT_{part_1}"
                part_2 = datetime.datetime.now()
                part_2 = str(part_2)
                part_2 = part_2.replace(" ", "")
                part_3 = "".join([secrets.choice(string.ascii_letters) for _ in range(10)])
                token = f"{part_1}_{part_2}_{part_3}"
                return token
            elif version == 2:
                part_1 = "".join([secrets.choice(string.digits) for _ in range(20)])
                part_1 = f"UFT_{part_1}"
                part_2 = datetime.datetime.now().strftime("%Y%m%d%H%M%S%f")
                part_3 = "".join([secrets.choice(string.ascii_letters) for _ in range(10)])
                token = f"{part_1}_{part_2}_{part_3}"
                return token
            elif version == 3:
                part_1 = "".join([secrets.choice(characters) for _ in range(45)])
                part_1 = f"UFT_{part_1}"
                part_2 = datetime.datetime.now().strftime("%Y%m%d%H%M%S%f")
                part_3 = "".join([secrets.choice(characters) for _ in range(35)])
                token = f"{part_1}_{part_2}_{part_3}"
                return token
            else:
                error_msg = f"Version more than 3 is not supported in universal tokens. Please use lower versions or other subformats."
                logging.error(error_msg)
                raise NoVersionError(error_msg)
        @staticmethod
        def Telegram(tid, version: Optional[int]=4) -> str:
            """Token for Telegram"""
            try:
                tid = int(tid)
            except ValueError:
                error_msg = f"Expected integer in tid (Telegram ID). Got: {type(tid)}"
                logging.error(error_msg)
                raise InvalidIDError(error_msg)
            if version not in sVersions:
                error_msg = f"Version {version} is not yet here. Please use lower versions."
                logging.error(error_msg)
                raise NoVersionError(error_msg)
            if version == 1:
                part_1 = f"TFT_{tid}"
                part_2 = datetime.datetime.now()
                part_2 = str(part_2)
                part_2 = part_2.replace(" ", "")
                part_3 = "".join([secrets.choice(string.ascii_letters) for _ in range(10)])
                token = f"{part_1}_{part_2}_{part_3}"
                return token
            elif version == 2:
                part_1 = "".join([secrets.choice(string.digits) for _ in range(10)])
                part_1 = f"TFT_{part_1}"
                part_2 = tid
                part_3 = datetime.datetime.now().strftime("%Y%m%d%H%M%S%f")
                part_4 = "".join([secrets.choice(string.ascii_letters) for _ in range(10)])
                token = f"{part_1}_{part_2}_{part_3}_{part_4}"
                return token
            elif version == 3:
                part_1 = "".join([secrets.choice(characters) for _ in range(35)])
                part_1 = f"TFT_{part_1}"
                part_2 = tid
                part_3 = datetime.datetime.now().strftime("%Y%m%d%H%M%S%f")
                part_4 = "".join([secrets.choice(characters) for _ in range(35)])
                token = f"{part_1}_{part_2}_{part_3}_{part_4}"
                return token
            elif version == 4:
                part_1 = "".join([secrets.choice(V4chars) for _ in range(40)])
                part_1 = f"TFT_V4_{part_1}"
                part_2 = hashlib.sha256(str(tid).encode()).hexdigest()[:16]
                part_3 = datetime.datetime.now().strftime("%f%Y%m%d%H%M%S%f")
                part_4 = "".join([secrets.choice(V4chars) for _ in range(40)])
                token = f"{part_1}_{part_2}_{part_3}_{part_4}"
                return token
        @staticmethod
        def Discord(did, version: Optional[int]=4) -> str:
            """Token for Discord"""
            try:
                did = int(did)
            except ValueError:
                error_msg = f"Expected integer in did (Discord ID). Got: {type(did)}"
                logging.error(error_msg)
                raise InvalidIDError(error_msg)
            if version not in sVersions:
                error_msg = f"Version {version} is not yet here. Please use lower versions."
                logging.error(error_msg)
                raise NoVersionError(error_msg)
            if version == 1:
                part_1 = f"DFT_{did}"
                part_2 = datetime.datetime.now()
                part_2 = str(part_2)
                part_2 = part_2.replace(" ", "")
                part_3 = "".join([secrets.choice(string.ascii_letters) for _ in range(10)])
                token = f"{part_1}_{part_2}_{part_3}"
                return token
            elif version == 2:
                part_1 = "".join([secrets.choice(string.digits) for _ in range(10)])
                part_1 = f"DFT_{part_1}"
                part_2 = did
                part_3 = datetime.datetime.now().strftime("%Y%m%d%H%M%S%f")
                part_4 = "".join([secrets.choice(string.ascii_letters) for _ in range(10)])
                token = f"{part_1}_{part_2}_{part_3}_{part_4}"
                return token
            elif version == 3:
                part_1 = "".join([secrets.choice(characters) for _ in range(35)])
                part_1 = f"DFT_{part_1}"
                part_2 = did
                part_3 = datetime.datetime.now().strftime("%Y%m%d%H%M%S%f")
                part_4 = "".join([secrets.choice(characters) for _ in range(35)])
                token = f"{part_1}_{part_2}_{part_3}_{part_4}"
                return token
            elif version == 4:
                part_1 = "".join([secrets.choice(V4chars) for _ in range(40)])
                part_1 = f"DFT_V4_{part_1}"
                part_2 = hashlib.sha256(str(did).encode()).hexdigest()[:16]
                part_3 = datetime.datetime.now().strftime("%f%Y%m%d%H%M%S%f")
                part_4 = "".join([secrets.choice(V4chars) for _ in range(40)])
                token = f"{part_1}_{part_2}_{part_3}_{part_4}"
                return token
        @staticmethod
        def API(version: Optional[int]=3) -> str:
            """Token for APIs (No dates, no ids, no anything)"""
            if version not in sVersions:
                error_msg = f"Version {version} is not yet here. Please use lower versions."
                logging.error(error_msg)
                raise NoVersionError(error_msg)
            if version == 1:
                part_1 = "APIFTURLS_"
                part_2 = secrets.token_urlsafe(32)
                token = part_1 + part_2
                return token
            elif version == 2:
                part_1 = "APIFTURLS_"
                part_2 = secrets.token_urlsafe(50)
                token = part_1 + part_2
                return token
            elif version == 3:
                part_1 = "APIFTURLS_"
                part_2 = secrets.token_urlsafe(75)
                token = part_1 + part_2
                return token
            else:
                error_msg = f"Version more than 3 is not supported in API tokens. Please use lower versions or other subformats."
                logging.error(error_msg)
                raise NoVersionError(error_msg)
        @staticmethod
        def Data(data1: Optional[str]=None,  data2: Optional[str]=None, data3: Optional[str]=None, data4: Optional[str]=None, data5: Optional[str]=None) -> str:
            """Generates token with data you input, takes up to 5 datas, doesn't accept version"""
            fData = [d for d in [data1, data2, data3, data4, data5] if d is not None]
            token = "%".join(fData)
            return token
        @staticmethod
        def Custom(ID, version: Optional[int]=4) -> str:
            """Custom IDs token generator"""
            if version not in sVersions:
                error_msg = f"Version {version} is not yet here. Please use lower versions."
                logging.error(error_msg)
                raise NoVersionError(error_msg)
            if not isinstance(ID, (int, float, str)):
                error_msg = f"Invalid ID type: {type(ID)}. Expected int or str."
                logging.error(error_msg)
                raise InvalidIDError(error_msg)
            cid = str(ID).strip()
            if not cid or cid == "None":
                error_msg = f"Invalid ID provided: {ID}"
                logging.error(error_msg)
                raise InvalidIDError(error_msg)
            if version == 1:
                part_1 = f"CFT_{cid}"
                part_2 = "".join([secrets.choice(string.ascii_letters) for _ in range(10)])
                token = f"{part_1}_{part_2}"
                return token
            elif version == 2:
                part_1 = "".join([secrets.choice(string.digits) for _ in range(10)])
                part_1 = f"CFT_{part_1}"
                part_2 = cid
                part_3 = "".join([secrets.choice(string.ascii_letters) for _ in range(10)])
                token = f"{part_1}_{part_2}_{part_3}"
                return token
            elif version == 3:
                part_1 = "".join([secrets.choice(characters) for _ in range(35)])
                part_1 = f"CFT_{part_1}"
                part_2 = cid
                part_3 = "".join([secrets.choice(characters) for _ in range(35)])
                token = f"{part_1}_{part_2}_{part_3}"
                return token
            elif version == 4:
                part_1 = "".join([secrets.choice(V4chars) for _ in range(40)])
                part_1 = f"CFT_V4_{part_1}"
                part_2 = hashlib.sha256(str(cid).encode()).hexdigest()[:16]
                part_3 = "".join([secrets.choice(V4chars) for _ in range(40)])
                token = f"{part_1}_{part_2}_{part_3}"
                return token
