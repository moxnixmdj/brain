import time
from typing import List
from gibsondedup.parser.json_parser import parse_results
from gibsondedup.grouping.grouping import group_by_canonical_url
from gibsondedup.canonicalizer.canonicalizer import canonicalize
from gibsondedup.contracts.models import CanonicalResult
from gibsondedup.grouping.merger import merge_similar_groups

class DeduplicationEngine:
    """
    Main pipeline. Orchestrates all stages:
    parse → group → canonicalize
    """
    def __init__(self,similarity_threshold: float = 0.8):
        self.similarity_threshold = similarity_threshold

    def process(self, raw_results: list) -> dict:
        """
        Execute full deduplication pipeline.

        Input:  raw list of dicts from search APIs
        Output: dict with deduplicated results + metrics
        """
        start_time = time.time()

        # ── STAGE 1: PARSE ───────────────────────────────────
        parsed = parse_results(raw_results)

        # ── STAGE 2: GROUP ───────────────────────────────────
        groups = group_by_canonical_url(parsed)

        # ── STAGE 2.5: MERGE SIMILAR GROUPS ──────────────────
        merged_groups = merge_similar_groups(groups, threshold=self.similarity_threshold)
        # ── STAGE 3: CANONICALIZE ────────────────────────────
        results = canonicalize(merged_groups)

        # ── METRICS ──────────────────────────────────────────
        elapsed_ms = round((time.time() - start_time) * 1000, 2)

        return {
            "results": [self._serialize(r) for r in results],
            "meta": {
                "total_input":         len(raw_results),
                "total_parsed":        len(parsed),
                "total_output":        len(results),
                "duplicates_removed":  len(parsed) - len(results),
                "processing_time_ms":  elapsed_ms,
            }
        }

    def _serialize(self, result: CanonicalResult) -> dict:
        """Convert CanonicalResult to clean API-safe dict."""
        return {
            "title":              result.title,
            "url":                result.url,
            "canonical_url":      result.canonical_url,
            "description":        result.description,
            "sources":            result.sources,
            "duplicates_removed": result.duplicates_removed,
        }

__all__ = ["DeduplicationEngine"]