from dataclasses import dataclass, field
from typing import Optional

@dataclass
class RawSearchResult:
    title: str                        # Required
    url: str                          # Required
    description: Optional[str] = ""   # Optional
    source: Optional[str] = "unknown" # Optional

@dataclass
class NormalizedSearchResult:
    title: str
    url: str                          # Original URL
    canonical_url: str                # Normalized URL
    description: Optional[str] = ""
    source: Optional[str] = "unknown"

@dataclass
class CanonicalResult:
    title: str
    url: str
    canonical_url: str
    description: Optional[str] = ""
    sources: list = field(default_factory=list)
    duplicates_removed: int = 0

__all__ = [
    "RawSearchResult",
    "NormalizedSearchResult",
    "CanonicalResult"
]