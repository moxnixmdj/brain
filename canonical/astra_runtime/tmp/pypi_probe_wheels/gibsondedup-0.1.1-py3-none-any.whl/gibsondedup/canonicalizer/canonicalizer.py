from gibsondedup.contracts.models import NormalizedSearchResult, CanonicalResult
from typing import List, Dict

def canonicalize(groups: Dict[str, List[NormalizedSearchResult]]) -> List[CanonicalResult]:
    canonical_results = []
    for canonical_url, results in groups.items():
        if not results:
            continue
        # Find the result with the longest description to use as the canonical result and longest title
        canonical_result = max(results, key=lambda r: len(r.description or "") + len(r.title or ""))
        # Create a CanonicalResult with the sources and count of duplicates removed
        canonical_results.append(CanonicalResult(
            title=canonical_result.title,
            url=canonical_result.url,
            canonical_url=canonical_result.canonical_url,
            description=canonical_result.description,
            sources=[r.source for r in results],
            duplicates_removed=len(results) - 1
        ))
    return canonical_results

__all__ = [
    "canonicalize"
]