from typing import Dict, List
from gibsondedup.contracts.models import NormalizedSearchResult
from gibsondedup.normalizer.similarity import jaccard_similarity

DEFAULT_THRESHOLD = 0.8

def extract_domain(canonical_url: str) -> str:
    """Extract domain from canonical URL."""
    return canonical_url.split("/")[0]

def get_representative_title(group: List[NormalizedSearchResult]) -> str:
    """Get the longest title from a group to represent it."""
    return max(group, key=lambda r: len(r.title or "")).title or ""

def merge_similar_groups(
    groups: Dict[str, List[NormalizedSearchResult]],
    threshold: float = DEFAULT_THRESHOLD
) -> Dict[str, List[NormalizedSearchResult]]:
    """
    Merge groups with different URLs but similar titles.

    Algorithm:
    1. Group by exact domain
    2. Within same domain, compare titles with Jaccard
    3. If similarity >= threshold, merge groups
    4. Return merged groups

    Time complexity: O(k²) per domain where k = groups per domain
    """
    if not groups:
        return groups

    # Step 1: Bucket groups by domain
    domain_buckets: Dict[str, List[str]] = {}
    for canonical_url in groups:
        domain = extract_domain(canonical_url)
        if domain not in domain_buckets:
            domain_buckets[domain] = []
        domain_buckets[domain].append(canonical_url)

    # Step 2: Within each domain, find and merge similar groups
    merged: Dict[str, List[NormalizedSearchResult]] = {}
    absorbed: set = set()  # Track URLs already merged into another group

    for domain, urls in domain_buckets.items():
        for i, url_a in enumerate(urls):
            if url_a in absorbed:
                continue

            # Start with url_a's group
            if url_a not in merged:
                merged[url_a] = list(groups[url_a])

            title_a = get_representative_title(merged[url_a])

            for j, url_b in enumerate(urls):
                if i >= j:
                    continue
                if url_b in absorbed:
                    continue

                title_b = get_representative_title(groups[url_b])
                similarity = jaccard_similarity(title_a, title_b)

                if similarity >= threshold:
                    # Merge url_b's group into url_a's group
                    merged[url_a].extend(groups[url_b])
                    absorbed.add(url_b)

        # Add any unmerged groups from this domain
        for url in urls:
            if url not in absorbed and url not in merged:
                merged[url] = list(groups[url])

    return merged

__all__ = ["merge_similar_groups", "extract_domain", "DEFAULT_THRESHOLD"]