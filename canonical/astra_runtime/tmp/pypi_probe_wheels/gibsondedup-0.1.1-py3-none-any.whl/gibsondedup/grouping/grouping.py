# Group Normalized urls into Canonical urls
from gibsondedup.contracts.models import NormalizedSearchResult
from collections import defaultdict
from typing import List, Dict

def group_by_canonical_url(results: List[NormalizedSearchResult]) ->Dict[str, List[NormalizedSearchResult]]:
    grouped = defaultdict(list)
    for result in results:
        # Check is key exists and is not empty, if not create new key with empty list
        # Ensure the canonical_url is not empty before grouping
        if result.canonical_url:
            grouped[result.canonical_url].append(result)
    return dict(grouped)

__all__ = [
    "group_by_canonical_url"
]