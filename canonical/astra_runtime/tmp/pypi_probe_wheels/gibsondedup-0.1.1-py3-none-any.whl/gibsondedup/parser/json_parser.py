from gibsondedup.contracts.models import RawSearchResult, NormalizedSearchResult
from gibsondedup.normalizer.url_normalizer import normalize_url
from typing import List

def parse_results(raw_results: list) -> List[NormalizedSearchResult]:
    """
    Parse raw JSON results into NormalizedSearchResult objects.
    Skips malformed records gracefully.
    """
    parsed = []

    for i, raw in enumerate(raw_results):
        # Skip non-dict entries
        if not isinstance(raw, dict):
            print(f"[PARSER] Skipping record {i}: not a dict")
            continue

        title = raw.get("title", "").strip()
        url   = raw.get("url", "").strip()

        # Skip records missing required fields
        if not title or not url:
            print(f"[PARSER] Skipping record {i}: missing title or url")
            continue

        # Normalize URL immediately at parse time
        canonical_url = normalize_url(url)

        parsed.append(NormalizedSearchResult(
            title=title,
            url=url,
            canonical_url=canonical_url,
            description=raw.get("description", "").strip(),
            source=raw.get("source", "unknown").strip(),
        ))

    return parsed

__all__ = ["parse_results"]