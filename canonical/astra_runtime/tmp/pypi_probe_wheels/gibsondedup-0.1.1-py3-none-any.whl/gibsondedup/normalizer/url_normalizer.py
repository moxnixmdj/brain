from urllib.parse import urlsplit, parse_qs, urlencode

TRACKING_PARAMS = {
    'utm_source', 'utm_medium', 'utm_campaign',
    'utm_content', 'utm_term', 'fbclid', 'gclid'
}

def normalize_url(url: str) -> str:
    # Handle empty input
    if not url:
        return ""
    # Ensure URL has a scheme for consistent parsing
    if not url.startswith(('http://', 'https://')):
        url = 'http://' + url
    # Step 1: Parse
    parsed = urlsplit(url)

    # Step 2: Remove www
    domain = parsed.netloc
    if domain.startswith('www.'):
        domain = domain[4:]

    # Remove port if present
    if ':' in domain:
        host, port = domain.rsplit(':', 1)
        if port in ('80', '443'):
            domain = host

    # Step 3: Strip trailing slash from path
    path = parsed.path.rstrip('/')

    # Step 4: Remove tracking params
    params = parse_qs(parsed.query)
    clean_params = {k: v for k, v in params.items() if k not in TRACKING_PARAMS}

    # Step 5: Reconstruct query string
    query_string = urlencode(clean_params, doseq=True)

    # Step 6: Reconstruct final URL
    canonical = f"{domain}{path}"
    if query_string:
        canonical += f"?{query_string}"

    return canonical.lower()

# TEST
if __name__ == "__main__":
    test_url = "https://www.example.com/path/?version=1&utm_source=google&utm_medium=cpc&fbclid=12345"
    print(normalize_url(test_url))  # Output: "example.com/path"
# Exports

__all__ = ["normalize_url"]