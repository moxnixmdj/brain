def tokenize(text:str) -> set:
    if not text.strip():
        return set()
    return set(text.lower().split())

def jaccard_similarity( text_a:str, text_b:str)-> float:
    # Find intersection
    list_a = tokenize(text_a)
    list_b = tokenize(text_b)
    intersection = list_a.intersection(list_b)
    # print("Intersection:", intersection)
    # Find union
    union = list_a.union(list_b)
    if not union:
        return 0.0
    # print("Union:", union)
    # Compute similarity
    similarity = len(intersection) / len(union)
    #print("Similarity:", similarity)
    return similarity
