# Test the canonicalizer function
import pytest
from gibsondedup.normalizer.url_normalizer import normalize_url
from gibsondedup.contracts.models import NormalizedSearchResult, CanonicalResult
from gibsondedup.grouping.grouping import group_by_canonical_url
from gibsondedup.canonicalizer.canonicalizer import canonicalize


# Test : Single result group -> zero duplicates removed
def test_canonicalize_single_result():
    results = [
        NormalizedSearchResult(title="Result 1", url="http://example.com/1", canonical_url="example.com/1", description="Description 1", source="source1")
    ]
    grouped = group_by_canonical_url(results)
    canonical_results = canonicalize(grouped)

    assert len(canonical_results) == 1
    assert canonical_results[0].title == "Result 1"
    assert canonical_results[0].url == "http://example.com/1"
    assert canonical_results[0].canonical_url == "example.com/1"
    assert canonical_results[0].description == "Description 1"
    assert canonical_results[0].sources == ["source1"]
    assert canonical_results[0].duplicates_removed == 0

# Test : Multiple results group -> duplicates removed = len(group) - 1
def test_canonicalize_multiple_results():
    results = [
        NormalizedSearchResult(title="Result 1", url="http://example.com/1", canonical_url="example.com/1", description="Description 1", source="source1"),
        NormalizedSearchResult(title="Result 2", url="http://example.com/2", canonical_url="example.com/1", description="Description 2 is longer than Description 1", source="source2"),
        NormalizedSearchResult(title="Result 3", url="http://example.com/3", canonical_url="example.com/3", description="Description 3", source="source3")
    ]
    grouped = group_by_canonical_url(results)
    canonical_results = canonicalize(grouped)

    assert len(canonical_results) == 2
    # Check the first canonical result (from the group with duplicates)
    assert canonical_results[0].title == "Result 2"
    assert canonical_results[0].url == "http://example.com/2"
    assert canonical_results[0].canonical_url == "example.com/1"
    assert canonical_results[0].description == "Description 2 is longer than Description 1"
    assert set(canonical_results[0].sources) == {"source1", "source2"}
    assert canonical_results[0].duplicates_removed == 1

    # Check the second canonical result (from the group with no duplicates)
    assert canonical_results[1].title == "Result 3"
    assert canonical_results[1].url == "http://example.com/3"
    assert canonical_results[1].canonical_url == "example.com/3"
    assert canonical_results[1].description == "Description 3"
    assert set(canonical_results[1].sources) == {"source3"}
    assert canonical_results[1].duplicates_removed == 0

# Test : Multiple results -> picks longest description and title combination
def test_canonicalize_longest_description_and_title():
    results = [
        NormalizedSearchResult(title="Short Title", url="http://example.com/1", canonical_url="example.com/1", description="Short Description", source="source1"),
        NormalizedSearchResult(title="Longer Title", url="http://example.com/2", canonical_url="example.com/1", description="Longer Description than Short Description", source="source2"),
        NormalizedSearchResult(title="Medium Title", url="http://example.com/3", canonical_url="example.com/1", description="Medium Description", source="source3")
    ]
    grouped = group_by_canonical_url(results)
    canonical_results = canonicalize(grouped)

    assert len(canonical_results) == 1
    assert canonical_results[0].title == "Longer Title"
    assert canonical_results[0].url == "http://example.com/2"
    assert canonical_results[0].canonical_url == "example.com/1"
    assert canonical_results[0].description == "Longer Description than Short Description"
    assert set(canonical_results[0].sources) == {"source1", "source2", "source3"}
    assert canonical_results[0].duplicates_removed == 2

# Sources collected correctly from ALL results in the group
def test_canonicalize_sources_collected():
    results = [
        NormalizedSearchResult(title="Result 1", url="http://example.com/1", canonical_url="example.com/1", description="Description 1", source="source1"),
        NormalizedSearchResult(title="Result 2", url="http://example.com/2", canonical_url="example.com/1", description="Description 2", source="source2"),
        NormalizedSearchResult(title="Result 3", url="http://example.com/3", canonical_url="example.com/1", description="Description 3", source="source3")
    ]
    grouped = group_by_canonical_url(results)
    canonical_results = canonicalize(grouped)

    assert len(canonical_results) == 1
    assert set(canonical_results[0].sources) == {"source1", "source2", "source3"}

# Empty groups are skipped and not included in the final canonical results
def test_canonicalize_empty_groups():
    results = [
        NormalizedSearchResult(title="Result 1", url="http://example.com/1", canonical_url="example.com/1", description="Description 1", source="source1"),
        NormalizedSearchResult(title="Result 2", url="http://example.com/2", canonical_url="", description="Description 2", source="source2")
    ]
    grouped = group_by_canonical_url(results)
    canonical_results = canonicalize(grouped)

    assert len(canonical_results) == 1
    assert canonical_results[0].canonical_url == "example.com/1"
    assert canonical_results[0].sources == ["source1"]
    assert canonical_results[0].duplicates_removed == 0

# Test : Normalization of URLs is correctly reflected in the canonicalization process, ensuring that different URL variations are grouped together and processed as a single canonical result.
def test_canonicalize_with_normalized_urls():
    results = [
        NormalizedSearchResult(title="Result 1", url="http://example.com/1?utm_source=google", canonical_url=normalize_url("http://example.com/1?utm_source=google"), description="Description 1", source="source1"),
        NormalizedSearchResult(title="Result 2", url="http://example.com/1?utm_source=bing", canonical_url=normalize_url("http://example.com/1?utm_source=bing"), description="Description 2", source="source2"),
        NormalizedSearchResult(title="Result 3", url="http://example.com/3", canonical_url=normalize_url("http://example.com/3"), description="Description 3", source="source3")
    ]
    grouped = group_by_canonical_url(results)
    canonical_results = canonicalize(grouped)

    assert len(canonical_results) == 2
    assert canonical_results[0].canonical_url == "example.com/1"
    assert set(canonical_results[0].sources) == {"source1", "source2"}
    assert canonical_results[0].duplicates_removed == 1

    assert canonical_results[1].canonical_url == "example.com/3"
    assert set(canonical_results[1].sources) == {"source3"}
    assert canonical_results[1].duplicates_removed == 0


# Test : Edge cases such as groups with all empty descriptions or titles are handled gracefully, ensuring that the canonicalization process does not fail and produces meaningful results even when some data is missing.
def test_canonicalize_edge_cases_empty_descriptions_and_titles():
    results = [
        NormalizedSearchResult(title="", url="http://example.com/1", canonical_url="example.com/1", description="", source="source1"),
        NormalizedSearchResult(title="", url="http://example.com/2", canonical_url="example.com/1", description="", source="source2"),
        NormalizedSearchResult(title="", url="http://example.com/3", canonical_url="example.com/1", description="", source="source3")
    ]
    grouped = group_by_canonical_url(results)
    canonical_results = canonicalize(grouped)

    assert len(canonical_results) == 1
    assert canonical_results[0].title == ""
    assert canonical_results[0].description == ""
    assert set(canonical_results[0].sources) == {"source1", "source2", "source3"}
    assert canonical_results[0].duplicates_removed == 2
