import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from gibsondedup.grouping.merger import merge_similar_groups, extract_domain
from gibsondedup.contracts.models import NormalizedSearchResult

# ── HELPERS ──────────────────────────────────────────
def make_result(title, url, canonical_url, source="google"):
    return NormalizedSearchResult(
        title=title,
        url=url,
        canonical_url=canonical_url,
        description="",
        source=source
    )

# ── TEST EXTRACT DOMAIN ───────────────────────────────
class TestExtractDomain:

    def test_simple_domain(self):
        assert extract_domain("python.org/docs") == "python.org"

    def test_subdomain(self):
        assert extract_domain("docs.python.org/ref") == "docs.python.org"

    def test_no_path(self):
        assert extract_domain("stackoverflow.com") == "stackoverflow.com"

    def test_deep_path(self):
        assert extract_domain("github.com/python/cpython") == "github.com"


# ── TEST MERGE SIMILAR GROUPS ─────────────────────────
class TestMergeSimilarGroups:

    def test_merges_similar_titles_same_domain(self):
        groups = {
            "python.org/docs": [
                make_result("Python Official Documentation", "https://python.org/docs", "python.org/docs")
            ],
            "python.org/reference": [
                make_result("Python Official Documentation Guide", "https://python.org/reference", "python.org/reference")
            ],
        }
        merged = merge_similar_groups(groups, threshold=0.5)
        # Both have similar titles + same domain → should merge
        assert len(merged) == 1
    

    def test_does_not_merge_different_domains(self):
        groups = {
            "python.org/docs": [
                make_result("Python Official Documentation", "https://python.org/docs", "python.org/docs")
            ],
            "docs.python.org/ref": [
                make_result("Python Official Documentation", "https://docs.python.org/ref", "docs.python.org/ref")
            ],
        }
        # Exact domain match - python.org != docs.python.org
        merged = merge_similar_groups(groups, threshold=0.8)
        assert len(merged) == 2

    def test_does_not_merge_dissimilar_titles(self):
        groups = {
            "python.org/docs": [
                make_result("Python Documentation", "https://python.org/docs", "python.org/docs")
            ],
            "python.org/tutorial": [
                make_result("Django Web Framework Guide", "https://python.org/tutorial", "python.org/tutorial")
            ],
        }
        merged = merge_similar_groups(groups, threshold=0.8)
        assert len(merged) == 2

    def test_empty_groups(self):
        assert merge_similar_groups({}) == {}

    def test_single_group_unchanged(self):
        groups = {
            "python.org/docs": [
                make_result("Python Docs", "https://python.org/docs", "python.org/docs")
            ]
        }
        merged = merge_similar_groups(groups)
        assert len(merged) == 1

    def test_respects_custom_threshold(self):
        groups = {
            "python.org/docs": [
                make_result("Python Official Documentation", "https://python.org/docs", "python.org/docs")
            ],
            "python.org/reference": [
                make_result("Python Official Docs Reference", "https://python.org/reference", "python.org/reference")
            ],
        }
        # High threshold → don't merge
        strict = merge_similar_groups(groups, threshold=0.99)
        assert len(strict) == 2

        # Low threshold → merge
        lenient = merge_similar_groups(groups, threshold=0.3)
        assert len(lenient) == 1

    def test_merged_group_contains_all_results(self):
        groups = {
            "python.org/docs": [
                make_result("Python Official Documentation", "https://python.org/docs", "python.org/docs", "google")
            ],
            "python.org/reference": [
                make_result("Python Official Docs Reference", "https://python.org/reference", "python.org/reference", "bing")
            ],
        }
        merged = merge_similar_groups(groups, threshold=0.5)
        # Merged group should have both results
        total_results = sum(len(v) for v in merged.values())
        assert total_results == 2