import pytest
from gibsondedup.orchestration.pipeline import DeduplicationEngine

engine = DeduplicationEngine()

# ── FIXTURES ─────────────────────────────────────────
SAMPLE_RESULTS = [
    # Group 1: 3 duplicates of python.org/docs
    {
        "title": "Python Official Documentation",
        "url": "https://www.python.org/docs?utm_source=google",
        "description": "Official Python docs from python.org",
        "source": "google"
    },
    {
        "title": "Python Docs",
        "url": "http://python.org/docs/",
        "description": "Python documentation",
        "source": "bing"
    },
    {
        "title": "Learn Python - Official Documentation Guide",
        "url": "https://python.org/docs?utm_medium=cpc&utm_source=bing",
        "description": "Complete Python documentation covering all modules",
        "source": "duckduckgo"
    },

    # Group 2: unique result
    {
        "title": "Stack Overflow - Python Questions",
        "url": "https://stackoverflow.com/questions/tagged/python",
        "description": "Python questions on Stack Overflow",
        "source": "google"
    },

    # Group 3: 2 duplicates of github.com/python
    {
        "title": "Python on GitHub",
        "url": "https://github.com/python/cpython",
        "description": "CPython source code",
        "source": "google"
    },
    {
        "title": "CPython - Python GitHub Repository",
        "url": "https://www.github.com/python/cpython?utm_source=newsletter",
        "description": "The official Python programming language repository",
        "source": "bing"
    },
]

MALFORMED_RESULTS = [
    {"title": "No URL here", "description": "Missing URL"},
    {"url": "https://example.com"},  # Missing title
    "just a string",                 # Not a dict
    {},                              # Empty dict
    {
        "title": "Valid Result",
        "url": "https://example.com/valid",
        "description": "This one is fine",
        "source": "google"
    },
]

# ── HAPPY PATH ───────────────────────────────────────
class TestDeduplicationPipeline:

    def test_returns_correct_structure(self):
        output = engine.process(SAMPLE_RESULTS)
        assert "results" in output
        assert "meta" in output

    def test_deduplicates_correctly(self):
        output = engine.process(SAMPLE_RESULTS)
        # 6 inputs → 3 unique groups
        assert output["meta"]["total_input"] == 6
        assert output["meta"]["total_output"] == 3
        assert output["meta"]["duplicates_removed"] == 3

    def test_meta_counts_are_accurate(self):
        output = engine.process(SAMPLE_RESULTS)
        meta = output["meta"]
        assert meta["total_input"] == 6
        assert meta["total_parsed"] == 6
        assert meta["total_output"] == 3
        assert meta["duplicates_removed"] == 3
        assert meta["processing_time_ms"] >= 0

    def test_results_have_correct_fields(self):
        output = engine.process(SAMPLE_RESULTS)
        for result in output["results"]:
            assert "title" in result
            assert "url" in result
            assert "canonical_url" in result
            assert "description" in result
            assert "sources" in result
            assert "duplicates_removed" in result

    def test_sources_collected_from_all_duplicates(self):
        output = engine.process(SAMPLE_RESULTS)
        # Find python.org group
        python_result = next(
            r for r in output["results"]
            if "python.org/docs" in r["canonical_url"]
        )
        assert set(python_result["sources"]) == {"google", "bing", "duckduckgo"}
        assert python_result["duplicates_removed"] == 2

    def test_processing_time_recorded(self):
        output = engine.process(SAMPLE_RESULTS)
        assert output["meta"]["processing_time_ms"] >= 0

    # ── EDGE CASES ───────────────────────────────────
    def test_empty_input(self):
        output = engine.process([])
        assert output["meta"]["total_input"] == 0
        assert output["meta"]["total_output"] == 0
        assert output["results"] == []

    def test_malformed_records_skipped(self):
        output = engine.process(MALFORMED_RESULTS)
        # Only 1 valid result out of 5
        assert output["meta"]["total_parsed"] == 1
        assert output["meta"]["total_output"] == 1
        assert output["results"][0]["title"] == "Valid Result"

    def test_single_result_no_duplicates(self):
        output = engine.process([SAMPLE_RESULTS[0]])
        assert output["meta"]["total_output"] == 1
        assert output["results"][0]["duplicates_removed"] == 0

    def test_all_duplicates_same_url(self):
        # All 3 point to same canonical URL
        same_url = [
            {"title": "A", "url": "https://example.com?utm_source=google", "source": "google"},
            {"title": "B longer title", "url": "https://www.example.com", "source": "bing"},
            {"title": "C", "url": "http://example.com/", "source": "duckduckgo"},
        ]
        output = engine.process(same_url)
        assert output["meta"]["total_output"] == 1
        assert output["results"][0]["duplicates_removed"] == 2
        assert len(output["results"][0]["sources"]) == 3