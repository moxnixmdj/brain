# Test the group by canonical url function
import pytest
from gibsondedup.contracts.models import NormalizedSearchResult
from gibsondedup.grouping.grouping import group_by_canonical_url
from gibsondedup.normalizer.url_normalizer import normalize_url

def test_group_by_canonical_url():
    # Create some test data
    results = [
        NormalizedSearchResult(title="Result 1", url="http://example.com/1", canonical_url="example.com/1"),
        NormalizedSearchResult(title="Result 2", url="http://example.com/2", canonical_url="example.com/1"),
        NormalizedSearchResult(title="Result 3", url="http://example.com/3", canonical_url="example.com/3"),
        NormalizedSearchResult(title="Result 4", url="http://example.com/4", canonical_url="")
    ]

    grouped = group_by_canonical_url(results)

    assert len(grouped) == 2
    assert len(grouped["example.com/1"]) == 2
    assert len(grouped["example.com/3"]) == 1
    assert "example.com/4" not in grouped


def test_group_by_canonical_url_empty():
    results = []
    grouped = group_by_canonical_url(results)
    assert grouped == {}


def test_group_by_canonical_url_no_canonical():
    results = [
        NormalizedSearchResult(title="Result 1", url="http://example.com/1", canonical_url=""),
        NormalizedSearchResult(title="Result 2", url="http://example.com/2", canonical_url="")
    ]
    grouped = group_by_canonical_url(results)
    assert grouped == {}

def test_normalize_url_into_group_by_canonical_url():
    # Create some test data with unnormalized URLs
    results = [
        NormalizedSearchResult(title="Result 1", url="http://example.com/1?utm_source=google", canonical_url=normalize_url("http://example.com/1?utm_source=google")),
        NormalizedSearchResult(title="Result 2", url="http://example.com/1?utm_source=bing", canonical_url=normalize_url("http://example.com/1?utm_source=bing")),
        NormalizedSearchResult(title="Result 3", url="http://example.com/3", canonical_url=normalize_url("http://example.com/3"))
    ]

    grouped = group_by_canonical_url(results)

    assert len(grouped) == 2
    assert len(grouped["example.com/1"]) == 2
    assert len(grouped["example.com/3"]) == 1