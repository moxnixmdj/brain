import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from gibsondedup.normalizer.similarity import jaccard_similarity, tokenize

class TestTokenize:

    def test_basic_tokenization(self):
        assert tokenize("hello world") == {"hello", "world"}

    def test_lowercases(self):
        assert tokenize("Python DOCS") == {"python", "docs"}

    def test_empty_string(self):
        assert tokenize("") == set()

    def test_whitespace_only(self):
        assert tokenize("   ") == set()

    def test_single_word(self):
        assert tokenize("Python") == {"python"}


class TestJaccardSimilarity:

    def test_identical_strings(self):
        assert jaccard_similarity("python docs", "python docs") == 1.0

    def test_no_overlap(self):
        assert jaccard_similarity("python docs", "ruby rails") == 0.0

    def test_partial_overlap(self):
        score = jaccard_similarity(
            "Python Official Documentation",
            "Official Python Docs"
        )
        assert 0.4 <= score <= 0.6  # ~0.5

    def test_empty_both(self):
        assert jaccard_similarity("", "") == 0.0

    def test_empty_one_side(self):
        assert jaccard_similarity("", "python docs") == 0.0
        assert jaccard_similarity("python docs", "") == 0.0

    def test_case_insensitive(self):
        assert jaccard_similarity("Python Docs", "python docs") == 1.0

    def test_high_similarity(self):
        score = jaccard_similarity(
            "Python Official Documentation Guide",
            "Python Official Documentation"
        )
        assert score >= 0.7

    def test_symmetry(self):
        # jaccard(A, B) == jaccard(B, A)
        a = "Python Official Documentation"
        b = "Official Python Docs"
        assert jaccard_similarity(a, b) == jaccard_similarity(b, a)