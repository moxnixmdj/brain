import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from gibsondedup.normalizer.url_normalizer import normalize_url

class TestNormalizeURL:

    # BASIC CASES
    def test_removes_www(self):
        assert normalize_url("https://www.python.org/docs") == "python.org/docs"

    def test_removes_trailing_slash(self):
        assert normalize_url("https://python.org/docs/") == "python.org/docs"

    def test_removes_tracking_params(self):
        assert normalize_url("https://python.org/docs?utm_source=google") == "python.org/docs"

    def test_removes_multiple_tracking_params(self):
        assert normalize_url("https://python.org/docs?utm_source=google&utm_medium=cpc&fbclid=123") == "python.org/docs"

    def test_preserves_meaningful_params(self):
        assert normalize_url("https://python.org/docs?version=3") == "python.org/docs?version=3"

    def test_removes_tracking_keeps_meaningful(self):
        assert normalize_url("https://python.org/docs?version=3&utm_source=google") == "python.org/docs?version=3"

    # PROTOCOL CASES
    def test_removes_https(self):
        assert normalize_url("https://python.org/docs") == "python.org/docs"

    def test_removes_http(self):
        assert normalize_url("http://python.org/docs") == "python.org/docs"

    def test_no_protocol(self):
        assert normalize_url("python.org/docs") == "python.org/docs"

    # EDGE CASES
    def test_empty_string(self):
        assert normalize_url("") == ""

    def test_lowercases_url(self):
        assert normalize_url("https://Python.ORG/Docs") == "python.org/docs"

    def test_three_variants_same_output(self):
        a = normalize_url("https://www.python.org/docs?utm_source=google")
        b = normalize_url("http://python.org/docs/")
        c = normalize_url("python.org/docs")
        assert a == b == c

    def test_removes_default_port(self):
        assert normalize_url("https://python.org:443/docs") == "python.org/docs"

    def test_keeps_non_default_port(self):
        assert normalize_url("https://python.org:8080/docs") == "python.org:8080/docs"