"""Generate a Pydantic v2 model file from a MongoDB ``$jsonSchema`` document.

Usage
-----
    python bson_to_pydantic.py \
        --schema-path=path/to/schema.json \
        --output-path=models.py \
        [--root-name=MyModel]

The input JSON file may contain any of the following at the top level:

* a raw ``$jsonSchema`` object (``{"bsonType": "object", "properties": {...}}``)
* ``{"$jsonSchema": {...}}``
* a Mongo collection validator: ``{"validator": {"$jsonSchema": {...}}}``

Notes
-----
* The *generator* itself only depends on the stdlib and ``fire``.
* The *generated* file depends on ``pydantic`` (v2) and, if the schema uses
  ``objectId``, on ``bson`` (shipped with ``pymongo``).
* Schema constraints (``minLength``, ``pattern``, ``enum``, numeric bounds,
  ``oneOf``/``allOf``) are intentionally **not** translated in this first
  version -- only types, optionality and ``description`` are honored.
* ``additionalProperties: false`` on an object schema produces
  ``model_config = ConfigDict(extra='forbid')`` on the corresponding model.
"""

from __future__ import annotations

import hashlib
import json
import keyword
import re
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------------
# BSON -> Python type mapping (scalar types only; container/object handled
# separately by the walker).
# ---------------------------------------------------------------------------

# Maps a BSON type name to (python_type_expr, import_spec) where import_spec
# is either None, or a tuple ``(module, name)`` where ``name`` is the symbol
# to import from ``module`` (``from module import name``), or ``name=None`` to
# emit a plain ``import module`` line.
_SCALAR_MAP: dict[str, tuple[str, tuple[str, str | None] | None]] = {
    "string": ("str", None),
    "int": ("int", None),
    "long": ("int", None),
    "double": ("float", None),
    "number": ("float", None),
    "decimal": ("Decimal", ("decimal", "Decimal")),
    "bool": ("bool", None),
    "boolean": ("bool", None),
    "date": ("datetime", ("datetime", "datetime")),
    "timestamp": ("datetime", ("datetime", "datetime")),
    "binData": ("bytes", None),
    "null": ("None", None),
    "objectId": ("ObjectId", ("bson", "ObjectId")),
    "regex": ("re.Pattern", ("re", None)),  # special: ``import re``
}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _to_pascal_case(name: str) -> str:
    """Turn an arbitrary identifier-ish string into PascalCase."""
    parts = re.split(r"[^0-9a-zA-Z]+", name)
    parts = [p for p in parts if p]
    if not parts:
        return "Field"
    pascal = "".join(p[:1].upper() + p[1:] for p in parts)
    if pascal[0].isdigit():
        pascal = "M" + pascal
    return pascal


def _safe_field_name(name: str) -> tuple[str, bool]:
    """Return (python_identifier, needs_alias).

    If *name* is a valid Python identifier that isn't a keyword and does not
    start with an underscore (Pydantic forbids those), it is returned
    unchanged. Otherwise a sanitized identifier is produced and the original
    name must be preserved via ``Field(alias=...)``.
    """
    if name.isidentifier() and not keyword.iskeyword(name) and not name.startswith("_"):
        return name, False
    sanitized = re.sub(r"[^0-9a-zA-Z_]", "_", name).lstrip("_")
    if not sanitized or sanitized[0].isdigit():
        sanitized = "f_" + sanitized
    if keyword.iskeyword(sanitized):
        sanitized += "_"
    return sanitized, True


def _unwrap_schema(raw: Any) -> dict[str, Any]:
    """Unwrap common Mongo validator wrappers to get the bare ``$jsonSchema``."""
    if not isinstance(raw, dict):
        msg = "Top-level JSON must be an object."
        raise ValueError(msg)
    if "validator" in raw and isinstance(raw["validator"], dict):
        raw = raw["validator"]
    if "$jsonSchema" in raw and isinstance(raw["$jsonSchema"], dict):
        raw = raw["$jsonSchema"]
    return raw


def _bson_types(schema: dict[str, Any]) -> list[str]:
    """Return the declared BSON types as a list (handles str or list)."""
    bt = schema.get("bsonType") or schema.get("type")
    if bt is None:
        return []
    if isinstance(bt, str):
        return [bt]
    if isinstance(bt, list):
        return [str(t) for t in bt]
    return []


# ---------------------------------------------------------------------------
# Generator
# ---------------------------------------------------------------------------


class _Generator:
    def __init__(self, root_name: str, line_length: int = 140) -> None:
        self.root_name = _to_pascal_case(root_name)
        self.line_length = line_length
        # Class definitions in dependency order (dependencies appended first).
        self._classes: list[tuple[str, list[str], dict[str, Any]]] = []
        self._used_names: set[str] = set()
        # Imports collected as a dict[module] -> set[name | "*module*"]; when
        # the value contains the sentinel ``None``-mapped entry "" we emit a
        # plain ``import <module>`` line instead of ``from ... import ...``.
        self._from_imports: dict[str, set[str]] = {}
        self._plain_imports: set[str] = set()
        # Always need these.
        self._from_imports.setdefault("pydantic", set()).update({"BaseModel", "Field"})

    # -- type resolution ----------------------------------------------------

    def _unique_class_name(self, desired: str) -> str:
        name = desired
        n = 2
        while name in self._used_names:
            name = f"{desired}{n}"
            n += 1
        self._used_names.add(name)
        return name

    def _add_import(self, spec: tuple[str, str | None]) -> None:
        module, name = spec
        if name is None:
            self._plain_imports.add(module)
        else:
            self._from_imports.setdefault(module, set()).add(name)

    def _resolve_scalar(self, bson_type: str) -> str:
        if bson_type not in _SCALAR_MAP:
            self._from_imports.setdefault("typing", set()).add("Any")
            return "Any"
        py_expr, imp = _SCALAR_MAP[bson_type]
        if imp is not None:
            self._add_import(imp)
        return py_expr

    def _resolve(self, schema: dict[str, Any], name_hint: str) -> str:
        """Return a Python type expression for *schema*."""
        # ``anyOf`` -> Union (only the optional case is reduced cleanly).
        if "anyOf" in schema and isinstance(schema["anyOf"], list):
            inner = [self._resolve(s, name_hint) for s in schema["anyOf"]]
            inner_unique = list(dict.fromkeys(inner))
            if "None" in inner_unique:
                inner_unique = [t for t in inner_unique if t != "None"]
                if len(inner_unique) == 1:
                    return f"{inner_unique[0]} | None"
                return " | ".join(inner_unique) + " | None"
            return " | ".join(inner_unique) if inner_unique else "Any"

        types = _bson_types(schema)
        if not types:
            # No type info -> fall back to Any.
            self._from_imports.setdefault("typing", set()).add("Any")
            return "Any"

        # Optional via ["foo", "null"].
        nullable = "null" in types
        non_null = [t for t in types if t != "null"]

        if not non_null:
            return "None"

        if len(non_null) == 1:
            base = self._resolve_single(non_null[0], schema, name_hint)
        else:
            parts = [self._resolve_single(t, schema, name_hint) for t in non_null]
            base = " | ".join(dict.fromkeys(parts))

        return f"{base} | None" if nullable else base

    def _resolve_single(self, bson_type: str, schema: dict[str, Any], name_hint: str) -> str:
        if bson_type == "object":
            # Nested model: only register a class when ``properties`` is given;
            # otherwise it's a free-form dict.
            if isinstance(schema.get("properties"), dict):
                cls_name = self._unique_class_name(_to_pascal_case(name_hint))
                self._register_object(cls_name, schema)
                return cls_name
            # Free-form object -> dict[str, Any]
            self._from_imports.setdefault("typing", set()).add("Any")
            return "dict[str, Any]"

        if bson_type == "array":
            items = schema.get("items")
            if isinstance(items, dict):
                inner = self._resolve(items, name_hint + "Item")
            elif isinstance(items, list) and items:
                # Tuple-style items: union them.
                inner_parts = [self._resolve(it, name_hint + "Item") for it in items]
                inner = " | ".join(dict.fromkeys(inner_parts))
            else:
                self._from_imports.setdefault("typing", set()).add("Any")
                inner = "Any"
            return f"list[{inner}]"

        return self._resolve_scalar(bson_type)

    # -- formatting helpers -------------------------------------------------

    def _wrap_kwarg(self, kwarg: str, indent: str) -> list[str]:
        """Wrap a ``key="value"`` kwarg across multiple lines if too long.

        Uses implicit string concatenation (``"foo " "bar"``) which both Python
        and ruff/black treat as a single literal. Splits on whitespace
        boundaries where possible, falling back to hard splits if a single word
        is wider than the available budget. Non-string kwargs (no double-quoted
        value) are returned unchanged with a trailing comma.
        """
        line = f"{indent}{kwarg},"
        if len(line) <= self.line_length:
            return [line]

        # Identify a simple ``key="value"`` pattern. Anything else: give up and
        # return the line as-is (caller already exceeded the limit).
        match = re.match(r'^([A-Za-z_][A-Za-z0-9_]*)="(.*)"$', kwarg)
        if match is None:
            return [line]

        key, value = match.group(1), match.group(2)
        # Budget per chunk: leave room for ``indent + '"' + chunk + '"' + ','``.
        # First chunk also carries ``key=``.
        budget_first = self.line_length - len(indent) - len(key) - 4  # key="",
        budget_rest = self.line_length - len(indent) - 3  # "",
        if budget_first < 1 or budget_rest < 1:
            return [line]

        chunks: list[str] = []
        remaining = value
        budget = budget_first
        while remaining:
            if len(remaining) <= budget:
                chunks.append(remaining)
                break
            # Prefer to break at the last whitespace within budget.
            cut = remaining.rfind(" ", 0, budget + 1)
            if cut <= 0:
                cut = budget
            else:
                cut += 1  # keep the trailing space with the current chunk
            chunks.append(remaining[:cut])
            remaining = remaining[cut:]
            budget = budget_rest

        out = [f'{indent}{key}="{chunks[0]}"']
        for c in chunks[1:-1]:
            out.append(f'{indent}"{c}"')
        if len(chunks) > 1:
            out.append(f'{indent}"{chunks[-1]}",')
        else:
            out[-1] += ","
        return out

    def _format_field(
        self,
        py_name: str,
        type_expr: str,
        is_required: bool,  # noqa FBT001
        field_kwargs: list[str],
        indent: str = "    ",
    ) -> list[str]:
        """Render a single field declaration honoring ``self.line_length``.

        Returns a list of source lines (always at least one).
        """
        default_repr = "..." if is_required else "None"
        # Plain ``name: Type`` (required, no Field metadata).
        if not field_kwargs and is_required:
            return [f"{indent}{py_name}: {type_expr}"]
        # Plain ``name: Type = None`` (optional, no Field metadata).
        if not field_kwargs:
            return [f"{indent}{py_name}: {type_expr} = None"]

        single = f"{indent}{py_name}: {type_expr} = Field({default_repr}, {', '.join(field_kwargs)})"
        if len(single) <= self.line_length:
            return [single]
        # Wrap each Field(...) argument on its own line, trailing comma.
        head = f"{indent}{py_name}: {type_expr} = Field("
        inner_indent = indent + "    "
        body: list[str] = [f"{inner_indent}{default_repr},"]
        for kw in field_kwargs:
            body.extend(self._wrap_kwarg(kw, inner_indent))
        body.append(f"{indent})")
        return [head, *body]

    def _format_config(self, indent: str, cfg_parts: list[str]) -> list[str]:
        """Render ``model_config = ConfigDict(...)`` honoring ``self.line_length``."""
        single = f"{indent}model_config = ConfigDict({', '.join(cfg_parts)})"
        if len(single) <= self.line_length:
            return [single]
        head = f"{indent}model_config = ConfigDict("
        inner_indent = indent + "    "
        body = [f"{inner_indent}{p}," for p in cfg_parts]
        body.append(f"{indent})")
        return [head, *body]

    # -- class registration -------------------------------------------------

    def _register_object(self, class_name: str, schema: dict[str, Any]) -> None:
        """Append a class definition for an ``object`` schema with properties.

        Nested classes referenced by this one are registered first (while
        resolving property types), so the final list is in dependency order.
        """
        properties: dict[str, Any] = schema.get("properties", {}) or {}
        required = set(schema.get("required", []) or [])
        additional_props = schema.get("additionalProperties")

        field_lines: list[str] = []
        # Track aliases / arbitrary types for config decisions below; collected
        # while iterating so we don't have to re-scan the rendered strings.
        any_alias = False
        needs_arbitrary = False
        needs_id_serializer = False
        for prop_name, prop_schema in properties.items():
            if not isinstance(prop_schema, dict):
                continue
            py_name, needs_alias = _safe_field_name(prop_name)
            type_expr = self._resolve(prop_schema, prop_name)
            is_required = prop_name in required
            if not is_required and "None" not in type_expr:
                type_expr = f"{type_expr} | None"

            field_kwargs: list[str] = []
            if needs_alias:
                field_kwargs.append(f'alias="{prop_name}"')
                any_alias = True
            description = prop_schema.get("description")
            if isinstance(description, str) and description:
                escaped = description.replace('"', '\\"')
                field_kwargs.append(f'description="{escaped}"')

            if any(t in type_expr for t in ("ObjectId", "re.Pattern")):
                needs_arbitrary = True

            # Track if this class has an 'id' field with ObjectId type
            if py_name == "id" and "ObjectId" in type_expr:
                needs_id_serializer = True

            field_lines.extend(self._format_field(py_name, type_expr, is_required, field_kwargs))

        config_lines: list[str] = []
        if any_alias or additional_props is False or needs_arbitrary:
            self._from_imports.setdefault("pydantic", set()).add("ConfigDict")
            cfg_parts: list[str] = []
            if any_alias:
                cfg_parts.append("populate_by_name=True")
            if additional_props is False:
                cfg_parts.append('extra="forbid"')
            if needs_arbitrary:
                cfg_parts.append("arbitrary_types_allowed=True")
            config_lines.extend(self._format_config("    ", cfg_parts))

        body: list[str] = []
        description = schema.get("description")
        if isinstance(description, str) and description:
            body.append(f'    """{description}"""')
            body.append("")
        body.extend(config_lines)
        if config_lines and field_lines:
            body.append("")
        body.extend(field_lines)
        if not body:
            body.append("    pass")

        # Store metadata including whether this class needs id field serializer
        metadata = {"needs_id_serializer": needs_id_serializer}
        self._classes.append((class_name, body, metadata))

    # -- public entry -------------------------------------------------------

    def build(
        self,
        root_schema: dict[str, Any],
        source_name: str | None = None,
        source_sha256: str | None = None,
    ) -> str:
        types = _bson_types(root_schema)
        if types and "object" not in types:
            msg = f"Root schema must describe an object, got bsonType={types!r}"
            raise ValueError(msg)
        root_cls = self._unique_class_name(self.root_name)
        self._register_object(root_cls, root_schema)
        return self._render(source_name=source_name, source_sha256=source_sha256)

    def _render(
        self,
        source_name: str | None = None,
        source_sha256: str | None = None,
    ) -> str:
        lines: list[str] = []
        doc_lines = ["Auto-generated by bson_to_pydantic.py. Do not edit by hand."]
        if source_name is not None:
            doc_lines.append("")
            doc_lines.append(f"Source: {source_name}")
        if source_sha256 is not None:
            doc_lines.append(f"SHA-256: {source_sha256}")
        if len(doc_lines) == 1:
            lines.append(f'"""{doc_lines[0]}"""')
        else:
            lines.append('"""' + doc_lines[0])
            lines.extend(doc_lines[1:])
            lines.append('"""')
        lines.append("")
        lines.append("from __future__ import annotations")
        lines.append("")
        if source_sha256 is not None:
            lines.append(f'__source_sha256__ = "{source_sha256}"')
            if source_name is not None:
                lines.append(f'__source_name__ = "{source_name}"')
            lines.append("")

        # Check if root class needs id field serializer
        root_needs_serializer = False
        if self._classes:
            _root_cls_name, _root_body, root_meta = self._classes[-1]
            root_needs_serializer = root_meta.get("needs_id_serializer", False)
            if root_needs_serializer:
                self._from_imports.setdefault("pydantic", set()).add("field_serializer")

        if self._plain_imports:
            for mod in sorted(self._plain_imports):
                lines.append(f"import {mod}")
            lines.append("")

        for mod in sorted(self._from_imports):
            names = sorted(self._from_imports[mod])
            lines.append(f"from {mod} import {', '.join(names)}")
        lines.append("")
        lines.append("")

        for i, (cls_name, body, meta) in enumerate(self._classes):
            lines.append(f"class {cls_name}(BaseModel):")
            lines.extend(body)

            # Add field_serializer for id field in root class if needed
            if meta.get("needs_id_serializer", False):
                if body and body[-1] != "":
                    lines.append("")
                lines.append('    @field_serializer("id", when_used="json")')
                lines.append("    def serialize_id(self, value: ObjectId) -> str:")
                lines.append("        return str(value)")

            if i != len(self._classes) - 1:
                lines.append("")
                lines.append("")

        lines.append("")
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------


def generate(
    schema_path: str,
    output_path: str,
    root_name: str = "Root",
    line_length: int = 140,
) -> None:
    """Generate a Pydantic v2 model file from a MongoDB ``$jsonSchema`` JSON file.

    Args:
        schema_path: Path to the input JSON file containing the schema.
        output_path: Path where the generated Python module is written.
        root_name: Name of the top-level generated ``BaseModel`` class.
        line_length: Soft maximum line length for generated source. Lines that
            would exceed this are wrapped using ruff/black-compatible style.
    """
    src = Path(schema_path)
    dst = Path(output_path)
    if not src.is_file():
        msg = f"Schema file not found: {src}"
        raise FileNotFoundError(msg)

    raw_bytes = src.read_bytes()
    source_sha256 = hashlib.sha256(raw_bytes).hexdigest()
    raw = json.loads(raw_bytes.decode("utf-8"))

    schema = _unwrap_schema(raw)
    generator = _Generator(root_name=root_name, line_length=line_length)
    code = generator.build(
        schema,
        source_name=src.name,
        source_sha256=source_sha256,
    )

    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_text(code, encoding="utf-8")
    print(f"Wrote {dst} ({len(generator._classes)} class(es), sha256={source_sha256[:12]}…).")  # noqa T201
