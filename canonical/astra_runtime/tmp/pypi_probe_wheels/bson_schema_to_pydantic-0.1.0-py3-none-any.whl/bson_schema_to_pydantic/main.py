from fire import Fire

from bson_schema_to_pydantic.bson_to_pydantic import generate


def main():
    Fire(generate)
